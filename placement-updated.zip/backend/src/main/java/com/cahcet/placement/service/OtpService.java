package com.cahcet.placement.service;

import com.cahcet.placement.entity.OtpVerification;
import com.cahcet.placement.exception.BadRequestException;
import com.cahcet.placement.repository.OtpVerificationRepository;
import com.cahcet.placement.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class OtpService {

    private final OtpVerificationRepository otpRepository;
    private final UserRepository userRepository;
    private final EmailService emailService;

    @Value("${app.otp.expiry-minutes:10}")
    private int otpExpiryMinutes;

    private static final int MAX_ATTEMPTS = 5;
    private static final SecureRandom RANDOM = new SecureRandom();

    /**
     * Step 1: Send OTP to email for verification before registration.
     */
    public String sendOtp(String email) {
        // Check if already registered
        if (userRepository.existsByEmail(email)) {
            throw new BadRequestException("This email is already registered. Please login.");
        }

        // Generate 6-digit OTP
        String otp = String.format("%06d", RANDOM.nextInt(1_000_000));

        // Check if an OTP already exists for this email and reuse the record, 
        // to prevent SQL Integrity constraint violations on the unique email column.
        OtpVerification verification = otpRepository.findByEmail(email).orElse(new OtpVerification());
        verification.setEmail(email);
        verification.setOtp(otp);
        verification.setExpiresAt(LocalDateTime.now().plusMinutes(otpExpiryMinutes));
        verification.setVerified(false);
        verification.setAttempts(0);

        otpRepository.save(verification);

        // Send OTP email - let errors propagate so user sees the real issue
        try {
            emailService.sendOtpEmail(email, otp, otpExpiryMinutes);
            log.info("OTP sent successfully for email: {}", email);
            return "OTP sent! Check your email inbox.";
        } catch (Exception e) {
            log.error("Email delivery failed for {}: {}", email, e.getMessage(), e);
            // Render Free Tier blocks outbound SMTP. Provide a fallback OTP message.
            return "Email blocked by host. Demo OTP is: " + otp + " [ERR: " + e.getMessage() + "]";
        }
    }

    /**
     * Step 2: Verify the OTP entered by the user.
     */
    public void verifyOtp(String email, String otp) {
        OtpVerification record = otpRepository.findByEmail(email)
            .orElseThrow(() -> new BadRequestException(
                "No OTP found for this email. Please request a new OTP."));

        if (record.isVerified()) {
            throw new BadRequestException("Email is already verified. Please complete registration.");
        }

        if (LocalDateTime.now().isAfter(record.getExpiresAt())) {
            otpRepository.delete(record);
            throw new BadRequestException(
                "OTP has expired. Please request a new OTP.");
        }

        if (record.getAttempts() >= MAX_ATTEMPTS) {
            otpRepository.delete(record);
            throw new BadRequestException(
                "Too many incorrect attempts. Please request a new OTP.");
        }

        if (!record.getOtp().equals(otp.trim())) {
            record.setAttempts(record.getAttempts() + 1);
            otpRepository.save(record);
            int remaining = MAX_ATTEMPTS - record.getAttempts();
            throw new BadRequestException(
                "Invalid OTP. " + remaining + " attempt(s) remaining.");
        }

        // Mark as verified
        record.setVerified(true);
        otpRepository.save(record);
        log.info("OTP verified successfully for email: {}", email);
    }

    /**
     * Check if an email has a valid (verified) OTP before allowing registration.
     */
    @Transactional(readOnly = true)
    public boolean isEmailVerified(String email) {
        return otpRepository.findByEmail(email)
            .map(OtpVerification::isVerified)
            .orElse(false);
    }

    /**
     * Cleanup after registration completes.
     */
    public void cleanupAfterRegistration(String email) {
        otpRepository.deleteByEmail(email);
    }
}
